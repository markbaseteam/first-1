---
F: B
review count: 5
---

- `2023-01-05T23:00` all day event (14:00 to 24:00)
- `2023-01-05T23:00 PT2H` event from 14:00 and lasts 2 hours
- `2023-01-05 2023-01-07` event from 9th december 24:00 to 11th december 24:00
- `2023-01-05 every 3 days` happens every 3 days

https://github.com/pmcintyre3/obsidian-add-css-attribtues-by-regex [(📁)](WebArchiver#Oulp0g)

- ID's can also be in the footer [^1]

[^1]: This is a DOI: 10.1017/9781108955652.006
[saitjr/raycast-obsidian-feishu (github.com)](https://github.com/saitjr/raycast-obsidian-feishu)

[Releases · Quorafind/Obsidian-Surfing (github.com)](https://github.com/Quorafind/Obsidian-Surfing/releases)

![[20230104075037.km]]

```tor2e
name: The Covetous Lurker
description: The Covetous Lurker is a worm-like creature that lives underground. It has great grasping claws which clash against cave walls as it pulls itself around its territory, searching for invaders which seek to steal its treasure.
features:
- Greedy
level: 7
endurance: 70
might: 2
hate: 7 # or resolve
parry: 0
armour: 3 # or armor
proficiencies:
- name: Rend
  rating: 3
  damage: 5
  injury: 16
  special: "[[Special Damage Options#Seize|Seize]]"
- name: Crush
  rating: 3
  damage: 7
  injury: 12
  special: "[[Special Damage Options#Break Shield|Break Shield]]"
abilities:
- "[[Fell Abilities#Fear of Fire|Fear of Fire]]"
- "[[Fell Abilities#Thing of Terror|Thing of Terror]]"
- "[[Fell Abilities#Thick Hide|Thick Hide]]"
```