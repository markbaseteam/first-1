## Ji2u8Y
{
    "url": "https://www.youtube.com/watch?v=pLQBZ1uYDac",
    "datetime": "2023-01-08T09:08:15",
    "internetArchive": {
        "archive": "https://web.archive.org/web/202301080908/https://www.youtube.com/watch?v=pLQBZ1uYDac",
        "status": "archived",
        "errCode": 0
    },
    "archiveToday": {
        "archive": "not available yet",
        "status": "not-started",
        "errCode": 0
    },
    "archiveBox": {
        "archive": "not available yet",
        "status": "not-started",
        "errCode": 0
    }
}
## XayABo
{
    "url": "https://www.youtube.com/watch?v=pLQBZ1uYDac",
    "datetime": "2023-01-08T09:08:27",
    "internetArchive": {
        "archive": "https://web.archive.org/web/202301080908/https://www.youtube.com/watch?v=pLQBZ1uYDac",
        "status": "archived",
        "errCode": 0
    },
    "archiveToday": {
        "archive": "not available yet",
        "status": "not-started",
        "errCode": 0
    },
    "archiveBox": {
        "archive": "not available yet",
        "status": "not-started",
        "errCode": 0
    }
}
