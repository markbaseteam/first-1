---
title: My First Modal!
okText: "Ok"
cancelText: "Cancel"
---

#### Modal Content

abc
```html

This is my first Modal!

```

#### Handle Ok
```javascript


```

#### Handle Cancel
```javascript

```

### Pre Render
```javascript


```

### Post Render
```javascript


```