---
mapWithTag: true
tagNames:
  - person
limit: 100
icon: clipboard-list
excludes: null
extends: null
version: 2
review count: 2
---


地址:: {"type":"Input","options":{}}

手机:: {"type":"Input","options":{}}

朋友:: {"type":"Input","options":{}}